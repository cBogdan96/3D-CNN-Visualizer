﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System;
using System.IO;

using System.Threading.Tasks;


public class Connector
{
    public string ip = "127.0.0.1";
    public int port;
    private TcpClient client;
    [SerializeField]
    private int dataOut;
    public Connector() { }
    public void establishConnection(int port)
    {
        this.port = port;
        client = new TcpClient();
        client.Connect(ip, port);
    }

    public byte[] SendAndReceive(byte[] cameraImput)
    {
        Debug.Log("I send on" + port);
        NetworkStream ns = client.GetStream();
        //byte[] intBytes = BitConverter.GetBytes();
        ns.Write(cameraImput, 0 , cameraImput.Length);

        byte[] z = new byte[1024 * 1024 * 1500];
        int byteIndex = 0;

        byte[] bytesToRead = new byte[1024 * 1024 * 1500];
        Array.Clear(bytesToRead, 0, bytesToRead.Length);

        int bytesRead = ns.Read(bytesToRead, 0, bytesToRead.Length);
        Buffer.BlockCopy(bytesToRead, 0, z, byteIndex, bytesRead);
        byteIndex += bytesRead;

        Array.Resize(ref z, byteIndex);
        //while (ns.DataAvailable) {
        //    ns.Read(bytesToRead, 0, bytesToRead.Length);
        //}
        //client.Close();
        if (bytesRead != 0)
        {
            Debug.Log("I receive on" + port);
            return z;
        }
        else
        {
            return null;
        }

        
    }

    /// <summary>
    /// Helper function for sending and receiving.
    /// </summary>
    /// <param name="dataOut">Data to send</param>
    /// <returns></returns>
    // public byte[] ServerRequest(int dataOut)
    // {
    //     //print("request");
    //     this.dataOut = dataOut; //debugging
    //     this.dataIn = SendAndReceive(dataOut); //debugging
    //     return this.dataIn;
    // }

    // /// <summary> 
    // /// Send data to port, receive data from port.
    // /// </summary>
    // /// <param name="dataOut">Data to send</param>
    // /// <returns></returns>
    // private byte[] SendAndReceive(int dataOut)
    // {
    //     byte[] z = new byte[1024 * 1024 * 1500];
    //     try
    //     {

    //         byte[] intBytes = BitConverter.GetBytes(dataOut);
    //         client.Send(intBytes);
    //         client.ReceiveTimeout = 2000;

    //         //allocate and receive bytes
    //         byte[] bytes = new byte[1024 * 1024 * 1500];
    //         Array.Clear(bytes, 0, bytes.Length);



    //         int lenght = 1, byteIndex = 0;
    //         // while( lenght != 0)
    //         // {

    //         lenght = client.Receive(bytes); // is blocking here cos no data is received   
    //         Buffer.BlockCopy(bytes, 0, z, byteIndex, lenght);
    //         byteIndex += lenght;

    //         Array.Resize(ref z, byteIndex);
    //         Debug.Log("request received");
    //         // }
    //     }
    //     catch (Exception e)
    //     {
    //         Debug.Log("s-a dus de gard :))");
    //     }


    //     client.Close();
    //     return z;


    // }
}





// using (MemoryStream ms = new MemoryStream())
// {
//     while (true)
//     {
//         int read = ns.Read(bytes, 0, bytes.Length);
//         if (read <= 0)
//             return ms.ToArray();
//         ms.Write(bytes, 0, read);
//     }
// }