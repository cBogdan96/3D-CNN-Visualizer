﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;

using System;
using System.IO;

using MessagePack;
using System.Threading;


using System.Text;
using System.Security.Cryptography;

public class Main : MonoBehaviour
{
    public static WebCamTexture backCam;
    public byte[] webcamBytes = new byte[17709];
    FeatureMapCreator featureMapCreator;
    //public static Texture2D webcamTexture;
    public StructHelper featureMapsObjects = new StructHelper();
    Connector socketConnector = new Connector();
    public volatile Dictionary<string, Dictionary<string, ushort[][]>> feature;
    public volatile Dictionary<string, Color[]> featureMapPixels = new Dictionary<string, Color[]>();
    public volatile Dictionary<string, Color[]> featureMapPixelsLastLayers = new Dictionary<string, Color[]>();
    public volatile Dictionary<string, KeyValuePair<string, string>> text = new Dictionary<string, KeyValuePair<string, string>>();
    public TextMesh textObject;
    List<string> prediction_labels;
    public volatile byte[] data;

    private float duration = 1f;
    private float timer = 0f;
    void Start()
    {
        FeatureMapCreator.predictions_labels = loadLabelsImageNet();
        featureMapCreator = new FeatureMapCreator(this);

        if (backCam == null)
            backCam = new WebCamTexture(224,224);

        GetComponent<Renderer>().material.mainTexture = backCam;

        if (!backCam.isPlaying)
            backCam.Play();
        Debug.Log(backCam.GetPixels());
        webcamBytes =  saveCamera();
        Connector socketConnector = new Connector();
        socketConnector.establishConnection(60000);
        var z = socketConnector.SendAndReceive(webcamBytes);
        DateTime start = DateTime.Now;
        feature = MessagePackSerializer.Deserialize<Dictionary<string, Dictionary<string, ushort[][]>>>(z);
        Debug.Log(DateTime.Now - start);

        featureMapsObjects = featureMapCreator.makeFeature(feature);
        //ThreadPool.QueueUserWorkItem

        Connector socketConnector1 = new Connector();
        socketConnector1.establishConnection(60001);
        Thread.Sleep(1000);
        Debug.Log(socketConnector1.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector1, this, featureMapCreator).init();

        Connector socketConnector2 = new Connector();
        socketConnector2.establishConnection(60002);
        Thread.Sleep(1000);
        Debug.Log(socketConnector2.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector2, this, featureMapCreator).init();

        Connector socketConnector3 = new Connector();
        socketConnector3.establishConnection(60003);
        Thread.Sleep(1000);
        Debug.Log(socketConnector3.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector3, this, featureMapCreator).init();

        Connector socketConnector4 = new Connector();
        socketConnector4.establishConnection(60004);
        Thread.Sleep(1000);
        Debug.Log(socketConnector4.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector4, this, featureMapCreator).init();

        Connector socketConnector5 = new Connector();
        socketConnector5.establishConnection(60005);
        Thread.Sleep(1000);
        Debug.Log(socketConnector5.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector5, this, featureMapCreator).init();

        Connector socketConnector6 = new Connector();
        socketConnector6.establishConnection(60006);
        Thread.Sleep(1000);
        Debug.Log(socketConnector6.port);
        //StartCoroutine(DelayOneSecond());
        new ThreadComponent(socketConnector6, this, featureMapCreator).init();

    }
    void Update()
    {
        // data =s
        //float timer1 = 0f;
        //timer1 += Time.deltaTime;
        lock (data)
        {
            data = saveCamera();
        }

        //ThreadComponent.setWebcamBytes(data);
        timer += Time.deltaTime;
        if (timer >= duration)
        {
            timer = 0f;

            if (featureMapPixels.Count != 0)
            {
                lock (featureMapPixels)
                {
                    Debug.Log(featureMapPixels);
                    foreach (KeyValuePair<string, Color[]> f in featureMapPixels)
                    {
                        featureMapsObjects.convLayers[f.Key].GetComponent<PlaneCreator>().updatePlane(f.Value);
                    }
                }
            }
            lock (featureMapPixelsLastLayers)
            {
                var index = 0;
                var indexLast = 0;
                var maxTest = -3.0;
                var minTest = 3.0;
                if (featureMapPixelsLastLayers.Count != 0)
                {
                    foreach (KeyValuePair<string, Color[]> f in featureMapPixelsLastLayers)
                    {
                        if (f.Key.Contains("predictions"))
                        {
                            if (f.Value[0].b > maxTest)
                            {
                                maxTest = f.Value[0].b;
                            }
                            if (f.Value[0].b < minTest)
                            {
                                minTest = f.Value[0].b;
                            }
                            featureMapsObjects.LastLayersPredictions[f.Key].GetComponent<CubeCreator>().updateCube(f.Value);
                            index++;
                        }
                        else
                        {
                            featureMapsObjects.LastLayersPredictions[f.Key].GetComponent<CubeCreator>().updateCube(f.Value);
                            indexLast++;
                        }
                    }
                }
                lock (text)
                {
                    foreach (KeyValuePair<string, KeyValuePair<string, string>> f in text)
                    {
                        textObject = GameObject.Find(f.Key).GetComponent<TextMesh>();
                        textObject.text = f.Value.Key + " " + f.Value.Value + "%";
                    }
                }
                Resources.UnloadUnusedAssets();
            }
        }
    }
    public void updateFeatureMapPixels(Dictionary<string, Color[]> featureMapPixels)
    {
        this.featureMapPixels = featureMapPixels;
    }
    public void updateTextAndLastLayers(Dictionary<string, Color[]> featureMapPixelsLastLayers, Dictionary<string, KeyValuePair<string, string>> text)
    {
        // pune lock
        this.featureMapPixelsLastLayers = featureMapPixelsLastLayers;
        this.text = text;
    }
    List<string> loadLabelsImageNet()
    {
        prediction_labels = new List<String>();
        string[] lines = System.IO.File.ReadAllLines("C:/Users/bcovrig/Desktop/PrivateStuff/thesis/Disertatie/imagenet_labels.txt");
        for (int i = 0; i < lines.Length; i++)
        {
            string val = lines[i].Split(':')[1].Trim();
            prediction_labels.Add(val);
        }

        return prediction_labels;
    }
    public  byte[]  saveCamera()
    {
        //if (!File.Exists(@"C:/Users/bcovrig/Desktop/PrivateStuff/thesis/Disertatie/p10.jpg"))
        //{
            Texture2D webcamTexture = new Texture2D(backCam.width, backCam.height);
            //Debug.Log(backCam.GetPixels()[5]);
            webcamTexture.SetPixels(backCam.GetPixels());
            webcamTexture.Apply();
            //System.IO.File.WriteAllBytes("C:/Users/bcovrig/Desktop/PrivateStuff/thesis/Disertatie/p4.jpg", webcamTexture.EncodeToJPG());

        //webcamBytes = webcamTexture.EncodeToPNG();
        //}
        var x = webcamTexture.EncodeToJPG();
        return x;

        //return webcamBytes;

        ////Texture2D.DestroyImmediate(webcamTexture, true);
        ////Destroy(webcamTexture);
        //Resources.UnloadUnusedAssets();
        //}
    }

    IEnumerator DelayOneSecond()
    {
        //This is a coroutine
        yield return new WaitForSeconds(1);
    }

    //private void setData(byte[] v)
    //{
    //    webcamBytes = v;
    //}
    public byte[] getData() {
        return data;
    }

    //public void StartTheThread(Connector socketConnector, Main main, FeatureMapCreator featureMapCreator)
    //{
    //    var t = new Thread(() => RealStart(socketConnector, main, featureMapCreator));
    //    t.Start();
    //}

    //private void RealStart(Connector socketConnector, Main main, FeatureMapCreator featureMapCreator)
    //{
        
    //}
}
