﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StructHelper 
{

    public Dictionary<string, KeyValuePair<string, ushort[][]>> featureMapList ;
    public Dictionary<string, KeyValuePair<string, ushort>> featureMapListLastLayers;

    public Dictionary<string, KeyValuePair<string, string>> textPredictions;
    public Dictionary<string, PlaneCreator> convLayers;
    public Dictionary<string, CubeCreator> LastLayersPredictions;
}
