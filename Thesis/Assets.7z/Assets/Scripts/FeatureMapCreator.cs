﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

using System;
public class FeatureMapCreator
{
    private FeatureMapData featureMapData = new FeatureMapData();
    public GameObject go;
    public Main main;
    public StructHelper structHelper = new StructHelper();

    public static List<string> predictions_labels  = new List<string>();
    public FeatureMapCreator(Main main)
    {
        this.main = main;
    }
    public Tuple<int, int> closestDivisors(int length)
    {
        int n = (int)Math.Floor(Math.Sqrt(length));
        Tuple<int, int> res = null;
        for (int i = n; i > 0; i--)
        {
            if (length % i == 0)
            {
                return res = new Tuple<int, int>(i, length / i);
            }
        }
        return res;
    }
    // map reference to the component instead of gameobjects
    public StructHelper makeFeature(Dictionary<string, Dictionary<string, ushort[][]>> feature)
    {
        initStructObjects();
        int index;
        int counter;
        Tuple<int, int> divisors;
        featureMapData.setCoordX(0);
        featureMapData.setCoordY(0);
        featureMapData.setCoordZ(0);

        foreach (KeyValuePair<string, Dictionary<string, ushort[][]>> layer in feature)
        {
            counter = 0;
            divisors = closestDivisors(layer.Value.Count);
            featureMapData.setCoordY(0);
            featureMapData.setCoordX(0);
            featureMapData.setCoordZ(featureMapData.getCoordZ() - 200);
            foreach (KeyValuePair<string, ushort[][]> featureMap in layer.Value)
            {
                featureMapData.setHeight(featureMap.Value.GetLength(0));
                featureMapData.setWidth(featureMap.Value.GetLength(0));
                featureMapData.setName(featureMap.Key);

                featureMapData.setCoordY(featureMapData.getCoordY() + featureMapData.getWidth() + featureMapData.getWidth() / 5);

                if(layer.Key.Contains("text")){
                    TextMesh textObject = GameObject.Find(layer.Key).GetComponent<TextMesh>();
                    textObject.text = featureMap.Key + " " + featureMap.Value[0][0].ToString() + "%";
                    if(!structHelper.textPredictions.ContainsKey(layer.Key)){
                        structHelper.textPredictions.Add(layer.Key,new KeyValuePair<string,string>(featureMap.Key,featureMap.Value[0][0].ToString()));
                    }
                }else if (featureMapData.getName().Contains("fc") ||featureMapData.getName().Contains("dense")||featureMapData.getName().Contains("predictions"))
                {
                    index = 0;
                    divisors = closestDivisors(featureMap.Value[0].Length);
                    var name = featureMapData.getName();
                    var featureMaps = featureMap.Value[0];
                    featureMapData.setCoordX(0);
                    featureMapData.setCoordY(0);
                    for (int i = 0; i < divisors.Item1; i++)
                    {
                        featureMapData.setCoordX(featureMapData.getCoordX() + 40);
                        featureMapData.setCoordY(0);
                        for (int j = 0; j < divisors.Item2; j++)
                        {
                            go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                            CubeCreator cube = go.AddComponent(typeof(CubeCreator)) as CubeCreator;
                            featureMapData.setCoordY(featureMapData.getCoordY() + 40);
                            if(featureMapData.getName().Contains("predictions")){
                                cube.createCube(featureMapData,name + "_" + predictions_labels[index] + "_" + index.ToString(), featureMaps[index]); 
                                structHelper.LastLayersPredictions.Add(name + "_" + predictions_labels[index] + "_" + index.ToString(), cube);
                            }else{
                                cube.createCube(featureMapData, name + "_" + index.ToString(), featureMaps[index]); 
                                structHelper.LastLayersPredictions.Add(name + "_" + index.ToString(), cube);
                            }
                            index++;
                        }
                    }
                }else
                {
                    go = new GameObject(featureMapData.getName());
                    PlaneCreator plane = go.AddComponent(typeof(PlaneCreator)) as PlaneCreator;
                    plane.createPlane(featureMapData, featureMap.Value);
                    structHelper.convLayers.Add(featureMap.Key, plane);
                }
                counter++;
                if (counter == divisors.Item2)
                {
                    featureMapData.setCoordY(0);
                    featureMapData.setCoordX(featureMapData.getCoordX() + featureMapData.getHeight() + featureMapData.getHeight() / 5);
                    counter = 0;
                }
            }
        }
        return structHelper; 
    }

    public StructHelper updateFeatures(Dictionary<string, Dictionary<string, ushort[][]>> feature)
    {
       initStructDataObjects();
        foreach (KeyValuePair<string, Dictionary<string, ushort[][]>> layer in feature)
        {
            Tuple<int, int> divisors = closestDivisors(layer.Value.Count());

            foreach (KeyValuePair<string, ushort[][]> featureMap in layer.Value)
            {
                if(layer.Key.Contains("text")){
                    structHelper.textPredictions[layer.Key] = new KeyValuePair<string,string>(featureMap.Key,featureMap.Value[0][0].ToString());
                }else if (featureMap.Key.Contains("fc") || featureMapData.getName().Contains("dense") || featureMap.Key.Contains("predictions"))
                {
                    var name = featureMap.Key;
                    int index = 0;
                    var featureMaps = featureMap.Value[0];
                    divisors = closestDivisors(featureMap.Value[0].Length);
                    for (int i = 0; i < divisors.Item1; i++)
                    {
                        for (int j = 0; j < divisors.Item2; j++)
                        {   
                            if(featureMap.Key.Contains("predictions")){
                                structHelper.featureMapListLastLayers[featureMap.Key+ "_" + predictions_labels[index]+ "_"+index.ToString()] = new KeyValuePair<string, ushort>(featureMap.Key+ "_" + predictions_labels[index]+ "_"+index.ToString(), featureMaps[index]);
                            }else{
                                structHelper.featureMapListLastLayers[featureMap.Key+ "_" + index.ToString()] = new KeyValuePair<string, ushort>(featureMap.Key+ "_" + index.ToString(), featureMaps[index]);
                            }
                            index++;
                        }
                    }
                }else
                {
                    structHelper.featureMapList[featureMap.Key] = featureMap;
                }
            }
        }
        return structHelper;
    }
    public void initStructObjects (){
        structHelper.textPredictions = new Dictionary<string, KeyValuePair<string, string>>();
        structHelper.LastLayersPredictions = new Dictionary<string, CubeCreator>();
        structHelper.convLayers = new Dictionary<string, PlaneCreator>();
    }
    public void initStructDataObjects(){
        structHelper.featureMapList = new Dictionary<string, KeyValuePair<string, ushort[][]>>();
        structHelper.featureMapListLastLayers = new Dictionary<string, KeyValuePair<string, ushort>>();
        structHelper.textPredictions = new Dictionary<string, KeyValuePair<string, string>>();
    }
}
