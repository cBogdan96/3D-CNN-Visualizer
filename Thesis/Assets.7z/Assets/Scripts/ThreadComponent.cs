﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using System.Linq;
using System.Threading.Tasks;

using MessagePack;
using System;
using System.Runtime.CompilerServices;

public class ThreadComponent
{
    private volatile string result;
    Thread thread;
    Connector socketConnector;
    Main main;
    FeatureMapCreator featureMapCreator;
    Dictionary<string, Dictionary<string, ushort[][]>> feature;
    StructHelper structHelper;
    byte[] z;
    volatile static byte[] webcamBytes;
   
    public ThreadComponent(Connector socketConnector, Main main, FeatureMapCreator featureMapCreator)
    {
        this.featureMapCreator = featureMapCreator;
        this.socketConnector = socketConnector;
        this.main = main;
    }

    public void init()
    {
        thread = new Thread(doLogic);
        thread.IsBackground = true;
        thread.Start();
    }
    void doLogic()
    {
        while (true)
        {
            
            if (main.getData() != null && main.getData().Length !=0)
            {
                var d = main.getData();
                Debug.Log(socketConnector.port);
                Task task1 = Task.Run(() => doLogicGetData( socketConnector,d));
                task1.Wait();
            }

        }

    }

    //public static void setWebcamBytes(byte[] webcambytes)
    //{
    //    ThreadComponent.webcamBytes = webcambytes;
    //}

    void doLogicGetData(Connector socketConnector, byte[] webcamImage)
    {
        
        //var tmp = new byte[2];
        //tmp = BitConverter.GetBytes(6);

        z = socketConnector.SendAndReceive(webcamImage);
        
        if (z != null) // size of the empty buffer
        {
            Debug.Log("doLogicGetData " + socketConnector.port);
            this.feature = MessagePackSerializer.Deserialize<Dictionary<string, Dictionary<string, ushort[][]>>>(z);
            structHelper = featureMapCreator.updateFeatures(feature);
            try
            {
                        var convPixelsFifthBatch = getConvPixels(structHelper.featureMapList);
                        var lastLayersPixels = getLastLayersPixels();
                        main.updateTextAndLastLayers(lastLayersPixels, structHelper.textPredictions);
                        main.updateFeatureMapPixels(convPixelsFifthBatch);
            }
            catch
            {
                Debug.Log("Data is not here yet");
            }

        }

    }
    public void stop()
    {
        thread.Interrupt();
    }
    public Dictionary<string, Color[]> getConvPixels(Dictionary<string, KeyValuePair<string, ushort[][]>> features)
    {
        Color color = new Color();
        color.a = 1f;
        Color[] pixels;

        Dictionary<string, Color[]> featureMapsPixels = new Dictionary<string, Color[]>();
        var values = features.Values;
        float normalizedValue;

        var max = -100000;
        var min = 100000;
        int index;

        foreach (KeyValuePair<string, ushort[][]> f in values)
        {
            index = 0;
            int height = f.Value.GetLength(0);
            int width = f.Value.GetLength(0);
            // new color 
            pixels = new Color[height * width];
            for (int k = 0; k < height; k++)
            {
                for (int l = 0; l < width; l++)
                {
                    if (f.Value[k][l] > max)
                    {
                        max = f.Value[k][l];
                    }

                    if (f.Value[k][l] < min)
                    {
                        min = f.Value[k][l];
                    }
                }
            }
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    normalizedValue = ((float)f.Value[i][j] - min) / (max - min);
                    color.r = normalizedValue;
                    color.g = normalizedValue;
                    color.b = normalizedValue;
                    pixels[index] = color;
                    index++;
                }
            }
            if (featureMapsPixels.ContainsKey(f.Key))
            {
                featureMapsPixels[f.Key] = pixels;
            }
            else
            {
                featureMapsPixels.Add(f.Key, pixels);
            }
        }
        return featureMapsPixels;
    }
    public Dictionary<string, Color[]> getLastLayersPixels()
    {
        Color color = new Color();
        color.a = 1f;
        Dictionary<string, Color[]> featureMapListLastLayersPixels = new Dictionary<string, Color[]>();
        float max = -10000f;
        float min = 10000f;
        foreach (KeyValuePair<string, ushort> f in structHelper.featureMapListLastLayers.Values)
        {
            if (f.Value > max)
            {
                max = f.Value;
            }

            if (f.Value < min)
            {
                min = f.Value;
            }
        }
        float normalizedValue;
        foreach (KeyValuePair<string, ushort> f in structHelper.featureMapListLastLayers.Values)
        {
            Color[] pixels = new Color[1];
            normalizedValue = ((float)f.Value - min) / (max - min);
            color.r = normalizedValue;
            color.g = normalizedValue;
            color.b = normalizedValue;
            pixels[0] = color;
            if (featureMapListLastLayersPixels.ContainsKey(f.Key))
            {
                featureMapListLastLayersPixels[f.Key] = pixels;
            }
            else
            {
                featureMapListLastLayersPixels.Add(f.Key, pixels);
            }
        }
        return featureMapListLastLayersPixels;
    }

}
