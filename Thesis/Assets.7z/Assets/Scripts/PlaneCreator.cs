﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

using System;
public class PlaneCreator : MonoBehaviour
{

    public Texture2D textureFeature;

    public int height, width;
    public void PlaneObject(FeatureMapData featureMapData, ushort[][] featureMap)
    {
        gameObject.name = featureMapData.getName();
        height = featureMapData.getHeight();
        width = featureMapData.getWidth();
        textureFeature = new Texture2D(featureMapData.getHeight(), featureMapData.getWidth());
        MeshFilter mf = gameObject.AddComponent(typeof(MeshFilter)) as MeshFilter;
        MeshRenderer mr = gameObject.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
        Mesh m = new Mesh();
        m.vertices = new Vector3[]
        {
            new Vector3(0,0,0),
            new Vector3(featureMapData.getWidth(),0,0),
            new Vector3(featureMapData.getWidth(),featureMapData.getHeight(),0),
            new Vector3(0, featureMapData.getHeight(), 0)

        };
        m.uv = new Vector2[]
        {
            new Vector2(0,0),
            new Vector2(0,1),
            new Vector2(1,1),
            new Vector2(1,0)
        };

        m.triangles = new int[] { 0, 1, 2, 0, 2, 3 };
        Color[] pixels = new Color[featureMapData.getHeight() * featureMapData.getWidth()];
        int index = 0;
        int max = -10000;
        int min = 10000;

        for (int k = 0; k < height; k++)
            {
                for (int l = 0; l < width; l++)
                {
                    if (featureMap[k][l] > max)
                    {
                        max = featureMap[k][l];
                    }

                    if (featureMap[k][l] < min)
                    {
                        min = featureMap[k][l];
                    }
                }
            }
        for (int i = 0; i < featureMap.GetLength(0); i++)
        {
            for (int j = 0; j < featureMap.GetLength(0); j++)
            {
                float normalizedValue = ((float)featureMap[i][j]- min) / (max - min);
                pixels[index] = new Color(normalizedValue, normalizedValue, normalizedValue, 1);
                index++;
            }
        }
        textureFeature.SetPixels(pixels);
        textureFeature.Apply();
        mf.mesh = m;
        mr.material.SetTexture("_MainTex", textureFeature); /// you will not need this in update 
        m.RecalculateBounds();
        m.RecalculateNormals();
        gameObject.transform.position = new Vector3(featureMapData.getCoordX(), featureMapData.getCoordY(), featureMapData.getCoordZ());
        gameObject.transform.Rotate(0, 0, -90, Space.Self);
    }

    private void updatePlaneObject(Color[] pixels)
    {
        MeshRenderer mr = gameObject.GetComponent(typeof(MeshRenderer)) as MeshRenderer;
        textureFeature.SetPixels(pixels);
        textureFeature.Apply();
        mr.material.SetTexture("_MainTex", textureFeature);
    }
    public void createPlane(FeatureMapData featureMapData, ushort[][] featureMap)
    {
        this.PlaneObject(featureMapData, featureMap);
        Resources.UnloadUnusedAssets();
    }
    public void updatePlane(Color[] pixels)
    {
        this.updatePlaneObject(pixels);
        Resources.UnloadUnusedAssets();
    }
}
